import pygame
import random
import math
import os
import asyncio  # важно для pygbag

# --- Настройки окна ---
WIDTH, HEIGHT = 900, 600
FPS = 60

SKY = (135, 206, 235)
WATER = (30, 100, 180)
GROUND = (90, 140, 60)
FLOAT_RED = (220, 40, 40)
FLOAT_WHITE = (240, 240, 240)
ROD_COLOR = (120, 70, 30)
LINE_COLOR = (220, 220, 220)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Рыбалка 🎣")
clock = pygame.time.Clock()
font_big = pygame.font.SysFont("arial", 36, bold=True)
font_mid = pygame.font.SysFont("arial", 24)
font_small = pygame.font.SysFont("arial", 18)

# ============ КООРДИНАТЫ ============
WATER_Y = 380
FLOAT_BASE_Y = WATER_Y + 15

FISHER_X = 215
FISHER_BOTTOM_Y = 495
FISHER_HEIGHT = 400

hand_x = 185
hand_y = 235
rod_dx = 300
rod_dy = -60

HEAD_SIZE = 110
head_offset_x = 110
head_offset_y = 45

# ============ ПУТИ (для веба файлы должны лежать рядом) ============
# ВАЖНО: в pygbag нельзя использовать абсолютные пути к рабочему столу.
# Все файлы (фон, рыбак, рыбы, голова) должны лежать в ТОЙ ЖЕ папке, что и main.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

BG_PATH = os.path.join(BASE_DIR, "lake.jpg")
FISHER_PATH = os.path.join(BASE_DIR, "Рисунок1.png")
UNCLE_PATH = os.path.join(BASE_DIR, "uncle.png")

# --- Фон ---
try:
    BG_IMG = pygame.image.load(BG_PATH).convert()
    BG_IMG = pygame.transform.smoothscale(BG_IMG, (WIDTH, HEIGHT))
    HAS_BG = True
    print("✓ Фон загружен")
except Exception as e:
    print("✗ Фон:", e)
    HAS_BG = False

# --- Персонаж ---
try:
    FISHER_IMG_RAW = pygame.image.load(FISHER_PATH).convert_alpha()
    ow, oh = FISHER_IMG_RAW.get_size()
    new_w = int(ow * (FISHER_HEIGHT / oh))
    FISHER_IMG = pygame.transform.smoothscale(FISHER_IMG_RAW, (new_w, FISHER_HEIGHT))
    HAS_FISHER = True
    print("✓ Персонаж загружен")
except Exception as e:
    print("✗ Персонаж:", e)
    HAS_FISHER = False

# --- Голова дяди ---
try:
    raw = pygame.image.load(UNCLE_PATH).convert_alpha()
    raw = pygame.transform.smoothscale(raw, (HEAD_SIZE, HEAD_SIZE))
    mask = pygame.Surface((HEAD_SIZE, HEAD_SIZE), pygame.SRCALPHA)
    pygame.draw.circle(mask, (255, 255, 255, 255),
                       (HEAD_SIZE // 2, HEAD_SIZE // 2), HEAD_SIZE // 2)
    UNCLE_IMG = pygame.Surface((HEAD_SIZE, HEAD_SIZE), pygame.SRCALPHA)
    UNCLE_IMG.blit(raw, (0, 0))
    UNCLE_IMG.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    HAS_UNCLE = True
    print("✓ Голова дяди загружена")
except Exception as e:
    print("✗ Голова дяди:", e)
    HAS_UNCLE = False

# ============ РЫБЫ ============
FISH_FILES = {
    "Сом":     "сом.png",
    "Щука":    "щука.png",
    "Карась":  "карась.png",
    "Окунь":   "окунь.png",
    "Лещ":     "лещ.png",
    "Карп":    "карп.png",
    "Плотва":  "плотва.png",
}

FISH_IMAGES = {}
FISH_TARGET_HEIGHT = 130

for fish_name, filename in FISH_FILES.items():
    path = os.path.join(BASE_DIR, filename)
    try:
        img = pygame.image.load(path).convert_alpha()
        ow, oh = img.get_size()
        new_w = int(ow * (FISH_TARGET_HEIGHT / oh))
        img = pygame.transform.smoothscale(img, (new_w, FISH_TARGET_HEIGHT))
        FISH_IMAGES[fish_name] = img
        print(f"✓ Рыба загружена: {fish_name}")
    except Exception as e:
        print(f"✗ Рыба {fish_name}: {e}")

# ============ СОСТОЯНИЯ ============
STATE_WAITING = "waiting"
STATE_BITE = "bite"
STATE_FAKE = "fake"
STATE_MISSED = "missed"
STATE_CAUGHT = "caught"


class Game:
    def __init__(self):
        self.reset()
        self.total_caught = 0
        self.best_fish = 0.0

    def reset(self):
        self.state = STATE_WAITING
        self.wait_timer = random.uniform(15.0, 20.0)
        self.bite_duration = random.uniform(0.40, 0.70)
        self.bite_timer = self.bite_duration
        self.next_fake_timer = self._plan_next_fake()
        self.fake_duration = 0.0
        self.fake_timer = 0.0
        self.message = ""
        self.message_timer = 0
        self.bob_time = 0
        self.float_offset = 0
        self.caught_weight = 0.0
        self.caught_name = ""

    def _plan_next_fake(self):
        return random.uniform(3.0, 7.0)

    def start_bite(self):
        self.state = STATE_BITE
        self.bite_timer = self.bite_duration

    def start_fake(self):
        self.state = STATE_FAKE
        self.fake_duration = random.uniform(0.6, 1.2)
        self.fake_timer = self.fake_duration

    def miss(self, reason=""):
        self.state = STATE_MISSED
        self.message = "Уплыла! 🐟💨" if not reason else reason
        self.message_timer = 1.2

    def empty_pull(self):
        self.state = STATE_MISSED
        self.message = "Померещилось! 🎣"
        self.message_timer = 1.2

    def catch(self):
        self.state = STATE_CAUGHT
        weight = round(random.uniform(0.2, 8.0), 2)
        if random.random() < 0.05:
            weight = round(random.uniform(8.0, 15.0), 2)
        self.caught_weight = weight
        if FISH_IMAGES:
            self.caught_name = random.choice(list(FISH_IMAGES.keys()))
        else:
            self.caught_name = random.choice(["Карась", "Окунь", "Щука"])
        self.message = f"{self.caught_name}: {weight} кг!"
        self.message_timer = 2.0
        self.total_caught += 1
        if weight > self.best_fish:
            self.best_fish = weight

    def update(self, dt):
        self.bob_time += dt
        if self.message_timer > 0:
            self.message_timer -= dt

        if self.state == STATE_WAITING:
            self.float_offset = math.sin(self.bob_time * 3) * 3
            self.wait_timer -= dt
            if self.wait_timer <= 0:
                self.start_bite()
                return
            self.next_fake_timer -= dt
            if self.next_fake_timer <= 0:
                self.start_fake()
                return

        elif self.state == STATE_FAKE:
            self.fake_timer -= dt
            progress = 1 - (self.fake_timer / self.fake_duration)
            self.float_offset = math.sin(progress * math.pi) * 35
            if self.fake_timer <= 0:
                self.state = STATE_WAITING
                self.float_offset = 0
                self.next_fake_timer = self._plan_next_fake()

        elif self.state == STATE_BITE:
            self.bite_timer -= dt
            progress = 1 - (self.bite_timer / self.bite_duration)
            self.float_offset = progress * 60
            if self.bite_timer <= 0:
                self.miss("Не успел! 😢")

        elif self.state in (STATE_MISSED, STATE_CAUGHT):
            if self.message_timer <= 0:
                tc, bf = self.total_caught, self.best_fish
                self.reset()
                self.total_caught, self.best_fish = tc, bf

    def on_click(self):
        if self.state == STATE_WAITING:
            self.miss("Рано! Пусто 🎣")
        elif self.state == STATE_FAKE:
            self.empty_pull()
        elif self.state == STATE_BITE:
            self.catch()


game = Game()


# ============ РИСОВАНИЕ ============
def draw_background():
    if HAS_BG:
        screen.blit(BG_IMG, (0, 0))
    else:
        screen.fill(SKY)
        pygame.draw.rect(screen, GROUND, (0, WATER_Y - 30, WIDTH, 30))
        pygame.draw.rect(screen, WATER, (0, WATER_Y, WIDTH, HEIGHT - WATER_Y))


def get_fisher_rect():
    rect = FISHER_IMG.get_rect()
    rect.midbottom = (FISHER_X, FISHER_BOTTOM_Y)
    return rect


def draw_fisher():
    if HAS_FISHER:
        rect = get_fisher_rect()
        screen.blit(FISHER_IMG, rect)
        if HAS_UNCLE:
            head_cx = rect.x + head_offset_x
            head_cy = rect.y + head_offset_y
            head_rect = UNCLE_IMG.get_rect(center=(head_cx, head_cy))
            screen.blit(UNCLE_IMG, head_rect)


def draw_rod_and_float():
    rod_end = (hand_x + rod_dx, hand_y + rod_dy)
    pygame.draw.line(screen, ROD_COLOR, (hand_x, hand_y), rod_end, 5)

    float_x = rod_end[0] + 40
    float_y = FLOAT_BASE_Y + game.float_offset
    depth = float_y - WATER_Y

    points = []
    for t in [i / 20 for i in range(21)]:
        px = rod_end[0] + (float_x - rod_end[0]) * t
        py = rod_end[1] + (float_y - rod_end[1]) * t
        py += math.sin(t * math.pi) * 15
        points.append((px, py))
    pygame.draw.lines(screen, LINE_COLOR, False, points, 1)

    if game.state == STATE_FAKE:
        pygame.draw.circle(screen, FLOAT_WHITE, (float_x, int(float_y) + 6), 8)
        pygame.draw.circle(screen, FLOAT_RED, (float_x, int(float_y) - 2), 8)
        pygame.draw.line(screen, (0, 0, 0),
                         (float_x, int(float_y) - 10),
                         (float_x, int(float_y) - 18), 2)
    elif depth < 25:
        pygame.draw.circle(screen, FLOAT_WHITE, (float_x, int(float_y) + 6), 8)
        pygame.draw.circle(screen, FLOAT_RED, (float_x, int(float_y) - 2), 8)
        pygame.draw.line(screen, (0, 0, 0),
                         (float_x, int(float_y) - 10),
                         (float_x, int(float_y) - 18), 2)
    else:
        if game.state == STATE_BITE:
            r = int(6 + depth * 0.3)
            alpha = max(0, 180 - int(depth * 3))
            s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (255, 255, 255, alpha), (r, r), r, 1)
            screen.blit(s, (float_x - r, WATER_Y - r))


def draw_caught_fish():
    if game.state != STATE_CAUGHT:
        return

    total = 2.0
    elapsed = total - max(0, game.message_timer)
    t = max(0.0, min(1.0, elapsed / total))

    start_x = hand_x + rod_dx + 40
    start_y = WATER_Y + 20
    end_x = WIDTH // 2 - 60
    end_y = WATER_Y - 220

    fx = start_x + (end_x - start_x) * t
    fy = start_y + (end_y - start_y) * t

    fish_img = FISH_IMAGES.get(game.caught_name)
    if fish_img is None:
        pygame.draw.ellipse(screen, (200, 120, 60), (fx - 40, fy - 15, 80, 30))
        pygame.draw.polygon(screen, (200, 120, 60),
                            [(fx + 40, fy), (fx + 55, fy - 15), (fx + 55, fy + 15)])
    else:
        rect = fish_img.get_rect(center=(fx, fy))
        screen.blit(fish_img, rect)

    label = font_mid.render(f"{game.caught_name} — {game.caught_weight} кг",
                            True, (255, 255, 255))
    label_shadow = font_mid.render(f"{game.caught_name} — {game.caught_weight} кг",
                                   True, (0, 0, 0))
    lx = fx - label.get_width() // 2
    ly = fy - FISH_TARGET_HEIGHT // 2 - 40
    screen.blit(label_shadow, (lx + 2, ly + 2))
    screen.blit(label, (lx, ly))


def draw_ui():
    text = "Нажми ПРОБЕЛ или КЛИК, когда поплавок уйдёт под воду"
    hint = font_mid.render(text, True, (255, 255, 255))
    shadow = font_mid.render(text, True, (0, 0, 0))
    x = WIDTH // 2 - hint.get_width() // 2
    screen.blit(shadow, (x + 2, 22))
    screen.blit(hint, (x, 20))

    stat_text = f"Поймано: {game.total_caught}   Лучший улов: {game.best_fish} кг"
    stats = font_small.render(stat_text, True, (255, 255, 255))
    stats_shadow = font_small.render(stat_text, True, (0, 0, 0))
    screen.blit(stats_shadow, (22, 22))
    screen.blit(stats, (20, 20))

    if game.state in (STATE_MISSED,) and game.message_timer > 0 and game.message:
        txt = font_big.render(game.message, True, (255, 255, 255))
        shadow_txt = font_big.render(game.message, True, (0, 0, 0))
        x = WIDTH // 2 - txt.get_width() // 2
        y = HEIGHT // 2 - 40
        screen.blit(shadow_txt, (x + 2, y + 2))
        screen.blit(txt, (x, y))


# ============ АСИНХРОННЫЙ ЦИКЛ (для pygbag) ============
async def main():
    global game
    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    game.on_click()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                game.on_click()

        game.update(dt)

        draw_background()
        draw_fisher()
        draw_rod_and_float()
        draw_caught_fish()
        draw_ui()

        pygame.display.flip()

        # КРИТИЧНО ДЛЯ БРАУЗЕРА: отдаём управление браузеру
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())